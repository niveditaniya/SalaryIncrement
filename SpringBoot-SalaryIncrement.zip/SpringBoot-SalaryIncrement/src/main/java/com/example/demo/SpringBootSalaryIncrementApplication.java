package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootSalaryIncrementApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootSalaryIncrementApplication.class, args);
	}
public void run() {
		
	}


}
