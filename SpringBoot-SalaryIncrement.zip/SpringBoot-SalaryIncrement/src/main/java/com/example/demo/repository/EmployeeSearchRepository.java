package com.example.demo.repository;


import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Employee;

@Repository
public class EmployeeSearchRepository {

	@Autowired
	MongoTemplate mongoTemplate;
	
	public Collection<Employee> searchEmployees(String text) {
		return mongoTemplate.find(Query.query(new Criteria()
						.orOperator(Criteria.where("id").regex(text, "i"), 
									Criteria.where("name").regex(text, "i"), 
									Criteria.where("description").regex(text, "i"))
						), Employee.class);
	}
	
}