package com.example.demo.controllers;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.Employee;
import com.example.demo.repository.EmployeeMongoRepository;
import com.example.demo.repository.EmployeeSearchRepository;

/**
 * 
 * @author nivedita
 *
 */

@Controller
public class EmployeeControllers {

	@Autowired
	EmployeeMongoRepository employeeRepository;

	@Autowired
	EmployeeSearchRepository employeeSearchRepository;

	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("empList", employeeRepository.findAll());
		return "home";
	}

	@RequestMapping(value = "/addEmployee", method = RequestMethod.POST)
	public String addEmployee(@ModelAttribute Employee emp) {
		System.out.println("Joining: " + emp.getJoiningDt());
		employeeRepository.save(emp);
		return "redirect:home";
	}

	@RequestMapping(value = "/search")
	public String search(Model model, @RequestParam String search) {
		model.addAttribute("empList", employeeSearchRepository.searchEmployees(search));
		model.addAttribute("search", search);
		return "home";
	}

	@RequestMapping(value = "/calculateIncrement")
	public String calculateIncrement(Model model, @RequestParam String name, @RequestParam String startDt,
			@RequestParam String endDt) throws ParseException {
		List<Employee> emps = (List<Employee>) employeeSearchRepository.searchEmployees(name);
		for (Employee employee : emps) {

			long monthsBetween = ChronoUnit.MONTHS.between(LocalDate.parse(startDt).withDayOfMonth(1),
					LocalDate.parse(endDt).withDayOfMonth(1));
			System.out.println(monthsBetween);

			int noOfQuater = (int) (monthsBetween / 4);
			long presentSal = getPresentSalary((long) employee.getSalary(), noOfQuater);
			employee.setDescription("No of quater in the specified duration: " + noOfQuater + " || PresentSal:  "
					+ presentSal + " || Incremented By:  " + (presentSal - (employee.getSalary())));

		}
		model.addAttribute("empList", emps);
		return "home";
	}

	public static Long getPresentSalary(Long oldSalary, int noOfQuater) {
		int hike = 10;

		while (noOfQuater > 0) {
			oldSalary = (Long) (oldSalary + (oldSalary * hike / 100));
			noOfQuater--;
		}

		return oldSalary;

	}

}
